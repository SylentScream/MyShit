// Copyright (C) 2002-2003 Axel Wernicke <axel.wernicke@gmx.de>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package org.tangouniform.jlibpod;

import java.util.Iterator;
import java.util.Vector;

/**
 * An iTunes Database object is related to an database file on an Apple iPod.
 * The database contains references to all music files on an iPod, as well as
 * meta information about the songs. Further all information about playlists on
 * the iPod.
 * 
 * All information are stored in a binary file, and is contained in tags. The
 * set of tags contains
 * 
 * <PRE>
 * 
 * mhbd - root tag of a database<BR>
 * mhsd - list holder, contains song lists or playlists<BR>
 * mhlt - song list header contains song items<BR>
 * mhit - song item, stores song meta information and is followed by one or more<BR>
 * mhod - song item content - stores one strings like artist, filetype, path
 * etc.<BR>
 * mhlp - playlist header, contains one or more playlist items<BR>
 * mhyp - playlist item holds the playlist in paires of<BR>
 * mhip - playlist index and mhod<BR>
 * 
 * an ITunesDB object stores the informations from the 'mhbd' tag and has
 * references to the content of all other tags.<BR>
 * 
 * @see techdoc for more details
 * @author axelwe
 */
public class PodTunesDB {

	/** tag size for the mhbd tag in bytes */
	private int tagSize = 104;

	/** database size in bytes */
	private int recordSize = 104;

	/** unknown content3 */
	private int unknown3 = 1;

	/** unknown content4 */
	private int unknown4 = 1;

	/** unknown content5 */
	private int unknown5 = 2;

	/** song list holder */
	private PodTunesDBListHolder songlistHolder = null;

	/** song list header */
	private PodTunesDBSonglistHeader songlistHeader = null;

	/** playlist holder */
	private PodTunesDBListHolder playlistHolder = null;

	/** playlist header */
	private PodTunesDBPlaylistHeader playlistHeader = null;

	/**
	 * Creates a new instance of an iTunesDB. An core object without any content
	 * is created.
	 */
	public PodTunesDB() {
	}

	/**
	 * Constructs a new iTunesDB object.
	 * 
	 * An empty, but valid database is created.
	 * 
	 * @param iPodName ,
	 *            used as name of the masterplaylist
	 */
	public PodTunesDB(String iPodName) {
		this();
		initSonglistHolder();
		initSonglistHeader();
		initPlaylistHolder();
		initPlaylistHeader(iPodName);
	}

	/**
	 * Initializes the songlist holder record of the database.
	 */
	public void initSonglistHolder() {
		songlistHolder = new PodTunesDBListHolder();
		songlistHolder.setListType(PodTunesDBListHolder.SONGLIST);

		// revalidate size
		recordSize += songlistHolder.getRecordSize();

	}

	/**
	 * initializes songlist header record.
	 */
	public void initSonglistHeader() {
		songlistHeader = new PodTunesDBSonglistHeader();

		// revalidate size
		songlistHolder.setRecordSize(songlistHolder.getRecordSize()
				+ songlistHeader.getTagSize());
		recordSize += songlistHeader.getTagSize();

	}

	/**
	 * initializes the playlist holder record.
	 */
	public void initPlaylistHolder() {

		playlistHolder = new PodTunesDBListHolder();
		playlistHolder.setListType(PodTunesDBListHolder.PLAYLIST);

		// revalidate size
		recordSize += playlistHolder.getRecordSize();

	}

	/**
	 * Initializes playlist header record. A masterplaylist is created.
	 * 
	 * @param iPodName
	 *            name of the master playlist (equals name of the iPod)
	 */
	public void initPlaylistHeader(String iPodName) {
		playlistHeader = new PodTunesDBPlaylistHeader();

		// revalidate size
		playlistHolder.setRecordSize(playlistHolder.getRecordSize()
				+ playlistHeader.getTagSize());
		this.recordSize += playlistHeader.getTagSize();

		// create masterplaylist
		createPlaylist(iPodName, null);

	}

	/**
	 * Gets the songlist holder record.
	 * 
	 * @return songlist holder record of the database
	 */
	public PodTunesDBListHolder getSonglistHolder() {
		return songlistHolder;
	}

	/**
	 * Gets the songlist header record
	 * 
	 * @return songlist record
	 */
	public PodTunesDBSonglistHeader getSonglistHeader() {
		return songlistHeader;
	}

	/**
	 * Gets the summarized size of all songs on the iPod
	 * 
	 * @return size of all songs in bytes
	 */
	public long getTotalFilesize() {

		long totalSize = -1;

		// TODO: clean up if( songlistHeader != null &&
		// songlistHeader.getSongItems() != null )
		if (songlistHeader != null) {
			totalSize = 0;

			// iterate over all songs
			for (int i = 0; i < songlistHeader.getSongCount(); i++) {
				totalSize += songlistHeader.getSongItem(i).getFilesize();
			}
		}

		return totalSize;
	}

	/**
	 * Gets the summarized size of all songs.
	 * 
	 * @param fileIdc
	 *            vector containing file indices to summarize size
	 * @return summarized size of selected songs
	 */
	public long getTotalFilesize(Vector fileIdc) {
		long totalSize = 0;

		// TODO: clean up if( songlistHeader != null &&
		// songlistHeader.getSongItems() != null )
		if (songlistHeader != null) {
			// iterate over all file indices
			for (Iterator iter = fileIdc.iterator(); iter.hasNext();) {
				totalSize += this.getFilesize(((Integer) iter.next())
						.longValue());
			}
		}

		return totalSize;
	}

	/**
	 * Gets the filename for a song from its file index.
	 * 
	 * @param fileIndex
	 *            of the song
	 * @return filename for the song
	 */
	public String getFilename(long fileIndex) {

		String filename = null;
		PodTunesDBSongItem songItem = null;
		PodTunesDBContentItem contentItem = null;
		boolean found = false;

		// iterate over all songs, until we find our file index
		for (int i = 0; i < songlistHeader.getSongCount() && !found; i++) {
			// get current song item and check if its our file index
			songItem = songlistHeader.getSongItem(i);
			if (songItem.getRecordIndex() == fileIndex) {
				// search path in an attached content records
				for (Iterator contentIter = songItem.getContentIterator(); !found
						&& contentIter.hasNext();) {
					contentItem = (PodTunesDBContentItem) contentIter.next();
					if (contentItem.getContentTyp() == PodTunesDBContentItem.PATH) {
						// hell, we found it =:)
						found = true;
						filename = contentItem.getContentAsString();
					}
				} // for all content items
			}
		} // for all song items

		return filename;
	}

	/**
	 * Gets the filesize for a song from the file index.
	 * 
	 * @param fileIndex
	 *            fileindex of the song
	 * @return size of the song in bytes
	 */
	public long getFilesize(long fileIndex) {

		long size = 0;
		boolean found = false;
		PodTunesDBSongItem songItem = null;

		// iterate over all songs
		for (int i = 0; i < songlistHeader.getSongCount() && !found; i++) {
			// get the current song item and check the file index
			songItem = songlistHeader.getSongItem(i);
			if (songItem.getRecordIndex() == fileIndex) {
				// yep, thats our boy
				found = true;
				size = songItem.getFilesize();
			}
		} // for all song items

		return size;
	}

	/**
	 * removes a song from the song list and all playlists.
	 * 
	 * <BR>- iterate over all playlists and remove clip by fileindex (filename
	 * without extension) <BR>- remove clip from the songlist
	 * 
	 * @param fileIndex
	 *            of the song to remove
	 */
	public void removeClip(long fileIndex) {
		// remove song from all playlists
		long removedSize = 0;
		for (int i = 0; i < playlistHeader.getPlaylistCount(); i++) {
			removedSize = playlistHeader.getPlaylist(i).removeClip(fileIndex);

			// revalidate sizes
			this.playlistHolder.setRecordSize((int) (this.playlistHolder
					.getRecordSize() - removedSize));
			this.recordSize -= removedSize;

		}

		// find song in song list
		boolean found = false;
		PodTunesDBSongItem songItem = null;
		for (int i = 0; i < songlistHeader.getSongCount() && !found; i++) {
			songItem = songlistHeader.getSongItem(i);
			if (songItem.getRecordIndex() == fileIndex) {
				found = true; // song item now contains the song to remove
			}
		}

		// save song item size
		long songRecordSize = songItem.getRecordSize();

		// remove song from song list and correct song list length
		songlistHeader.removeSongItem(songItem);

		// revalidate sizes
		songlistHolder
				.setRecordSize((int) (songlistHolder.getRecordSize() - songRecordSize));
		this.recordSize -= songRecordSize;

	}

	/**
	 * Adds a clip to song list and master playlist
	 * 
	 * @param fileIndex
	 *            of the song on the iPod
	 * @param meta
	 *            information about the song
	 */
	public void addClip(int fileIndex, MP3Meta meta) {

		// add clip to song list
		int songlistAddSize = songlistHeader.addClip(fileIndex, meta);

		// revalidate sizes
		recordSize += songlistAddSize;
		songlistHolder.setRecordSize(songlistHolder.getRecordSize()
				+ songlistAddSize);

		// add clip to master playlist
		PodTunesDBPlaylistItem masterPlaylist = (PodTunesDBPlaylistItem) playlistHeader
				.getPlaylist(0);
		int playlistAddSize = masterPlaylist.addClip(fileIndex);

		// revalidate sizes
		recordSize += playlistAddSize;
		playlistHolder.setRecordSize(playlistHolder.getRecordSize()
				+ playlistAddSize);

	}

	/**
	 * Determines the next available file index. This fileindex is used as base
	 * filename to store the song on iPod.
	 * 
	 * @param fileIndex
	 *            recently used file index or 0
	 * @return next available fileindex
	 */
	public int getNextAvailableSongIndex(int fileIndex) {

		// set start value
		int newIndex = fileIndex;

		// increment until we find an unused one
		do {
			newIndex++;
		} while (containsIndex(newIndex));

		return newIndex;
	}

	/**
	 * Checks if an file index is in the database.
	 * 
	 * @param index
	 *            to check
	 * @return true, if the file index was found in the database
	 */
	boolean containsIndex(int index) {

		boolean found = false;

		// iterate over all songs in the song list
		for (int i = 0; i < songlistHeader.getSongCount() && !found; i++) {
			if (songlistHeader.getSongItem(i).getRecordIndex() == index) {
				found = true;
			}
		}

		return found;
	}

	/**
	 * iterates over all playlists and removes them, if not a masterplaylist,
	 * but empty.
	 */
	public void removeEmptyPlaylists() {

		PodTunesDBPlaylistItem playlist = null;
		int size = 0;

		// iterate over all, but leave the first one
		for (int i = (int) playlistHeader.getPlaylistCount() - 1; i > 0; i--) {
			playlist = this.playlistHeader.getPlaylist(i);

			// remove if empty
			if (playlist.getSongCount() == 0) {
				// revalidate sizes
				size = playlist.getRecordSize();
				this.playlistHolder.setRecordSize(this.playlistHolder
						.getRecordSize()
						- size);
				this.recordSize -= size;

				// remove playlist
				this.playlistHeader.removePlaylist(i);

			}
		}
	} // remove empty playlist

	/**
	 * Removes a playlist from database.
	 * 
	 * @param playlist
	 *            playlist to remove
	 * @return true, if removing was sucessful
	 */
	boolean removePlaylist(PodTunesDBPlaylistItem playlist) {

		boolean result = false;
		long size = 0;

		// check that the playlist exists
		if (this.playlistHeader.containsPlaylist(playlist)) {
			// revalidate sizes
			size = playlist.getRecordSize();
			this.playlistHolder.setRecordSize((int) (this.playlistHolder
					.getRecordSize() - size));
			this.recordSize -= size;

			// remove playlist
			this.playlistHeader.removePlaylist(playlist);

			result = true;

		} else {
			result = false;
		}

		return result;
	}

	/**
	 * Validates the database. Record sizes and content count is checked.
	 * 
	 * <BR>- check db record size <BR>- check songlist holder size <BR>-
	 * check all song items size <BR>- check song item count <BR>- check
	 * playlist holder size <BR>- check all playlist items <BR>- check
	 * playlist count <BR>- check song count for each playlist
	 * 
	 * @return true, if the database is valid
	 */
	public boolean isValid() {
		// delegate
		return isValid(false);
	}

	/**
	 * Validates the database. Record sizes and content count is checked.
	 * 
	 * <BR>- check db record size <BR>- check songlist holder size <BR>-
	 * check all song items size <BR>- check song item count <BR>- check
	 * playlist holder size <BR>- check all playlist items <BR>- check
	 * playlist count <BR>- check song count for each playlist
	 * 
	 * @param correct
	 *            if true, the offsets are corrected
	 * @return true, if the database is valid
	 */
	public boolean isValid(boolean correct) {
		boolean valid = true;

		// check tag size, item counts and references
		valid = !(!tagSizesValid(correct) || !countsValid(correct) || !referencesValid(correct));

		return valid;

	} // validate

	/**
	 * Checks the size of the records of the data base.
	 */
	private boolean tagSizesValid(boolean correct) {

		boolean valid = true;
		int size;

		// instantiate a parser to check the database
		PodTunesDBParser parser = new PodTunesDBParser(this);

		// check db record
		size = parser.calculateRecordSize(this);
		if (size != this.recordSize) {
			valid = false;

			if (correct) {
				this.recordSize = size;
			}
		}

		// check songlist holder record
		size = parser.calculateRecordSize(this.songlistHolder)
				- this.songlistHolder.getTagSize();
		if (size != this.songlistHolder.getRecordSize()) {
			valid = false;

			if (correct) {
				this.songlistHolder.setRecordSize(size);
			}
		}

		// check all song items size
		PodTunesDBSongItem songItem;
		for (int i = 0; i < songlistHeader.getSongCount(); i++) {
			songItem = songlistHeader.getSongItem(i);
			size = parser.calculateRecordSize(songItem);
			if (size != songItem.getRecordSize()) {
				valid = false;

				if (correct) {
					songItem.setRecordSize(size);
				}
			}
		} // for all songs

		// check playlist holder size
		size = parser.calculateRecordSize(this.playlistHolder)
				- this.songlistHolder.getTagSize();
		if (size != this.playlistHolder.getRecordSize()) {
			valid = false;

			if (correct) {
				this.playlistHolder.setRecordSize(size);
			}
		}

		// check all playlist items size
		PodTunesDBPlaylistItem playlistItem;
		for (int i = 0; i < this.playlistHeader.getPlaylistCount(); i++) {
			playlistItem = this.playlistHeader.getPlaylist(i);
			size = parser.calculateRecordSize(playlistItem);
			if (size != playlistItem.getRecordSize()) {
				valid = false;

				if (correct) {
					playlistItem.setRecordSize(size);
				}
			}
		} // for all playlists

		return valid;
	}

	/**
	 * Creates a new playlist on iPod containing all the songs in the Vector.
	 * 
	 * @param name
	 *            of the playlist
	 * @param fileIdc
	 *            Vector of fileindices to include in the playlist
	 */
	public void createPlaylist(String name, Vector fileIdc) {

		int fileIndex = 0;
		// check if we have that playlist on iPod already
		PodTunesDBPlaylistItem playlist = getPlaylist(name);

		// remove that iPod playlist
		if (playlist != null) {
			removePlaylist(playlist);
		}

		// create new playlist
		playlist = new PodTunesDBPlaylistItem();
		playlist.setListType(0);
		playlist.setName(name);

		// add playlist to header
		playlistHeader.addPlaylist(playlist);

		// revalidate size
		playlistHolder.setRecordSize(playlistHolder.getRecordSize()
				+ playlist.getRecordSize());
		recordSize += playlist.getRecordSize();

		// add songs to playlist
		int addSize = 0;
		if (fileIdc != null) {
			for (Iterator fileIter = fileIdc.iterator(); fileIter.hasNext();) {
				fileIndex = ((Integer) fileIter.next()).intValue();
				addSize += playlist.addClip(fileIndex);

			}
		}

		// revalidate size
		this.playlistHolder.setRecordSize(this.playlistHolder.getRecordSize()
				+ addSize);
		this.recordSize += addSize;

	}

	/**
	 * Gets a playlist from the database by name.
	 * 
	 * @param name
	 *            of the playlist
	 * @return playlist, if found, null else
	 */
	PodTunesDBPlaylistItem getPlaylist(String name) {

		PodTunesDBPlaylistItem currPlaylist = null;
		PodTunesDBPlaylistItem foundPlaylist = null;
		boolean found = false;

		// iterate over all playlists
		for (int i = 0; i < this.playlistHeader.getPlaylistCount() && !found; i++) {
			currPlaylist = this.playlistHeader.getPlaylist(i);

			if (name.equals(currPlaylist.getName())) {
				found = true;
				foundPlaylist = currPlaylist;
			}
		}

		return foundPlaylist;
	}

	/**
	 * generates a string that represents the current object
	 * 
	 * @return string representation of the database
	 */
	public String toString() {
		return new StringBuffer("[tagSize] ").append(tagSize).append('\t')
				.append("[recordSize] ").append(recordSize).append('\t')
				.append("[unknown3] ").append(unknown3).append('\t').append(
						"[unknown4] ").append(unknown4).append('\t').append(
						"[unknown5] ").append(unknown5).toString();
	}

	/**
	 */
	private boolean countsValid(boolean correct) {
		boolean valid = true;

		// check item count of the playlists.
		PodTunesDBPlaylistItem playlistItem;
		for (int i = 0; i < this.playlistHeader.getPlaylistCount(); i++) {
			playlistItem = this.playlistHeader.getPlaylist(i);
			// check item count of the playlist. Its normal that playlist count
			// is less that items attached,
			// because two items are used for the playlist name
			if (playlistItem.getSongItems().size() - 2 != playlistItem
					.getSongCount()) {
				valid = false;

				if (correct) {
					playlistItem.setSongCount(playlistItem.getSongItems()
							.size() - 2);
				}
			}
		} // for all playlists

		return valid;
	}

	/**
	 */
	private boolean referencesValid(boolean correct) {

		boolean valid = true; // in german we call this "Unschuldsvermutung"
								// =:)

		// check references song items playlist -> songlist
		PodTunesDBPlaylistItem playlistItem;
		Object indexItem;
		for (int i = 0; i < this.playlistHeader.getPlaylistCount(); i++) {
			// iterate over all song index items
			playlistItem = this.playlistHeader.getPlaylist(i);
			for (Iterator indexIter = playlistItem.getSongItems().iterator(); indexIter
					.hasNext();) {
				// take care, the playlist contains content items as well as
				// index items...
				indexItem = indexIter.next();
				if (indexItem instanceof PodTunesDBPlaylistIndexItem
						&& !this.songlistHeader
								.containsClip(((PodTunesDBPlaylistIndexItem) indexItem)
										.getSongIndex())) {
					valid = false;
				}
			} // for all songs in the playlist
		} // for all playlists

		// check references song items -> file system

		return valid;
	}

	/**
	 * Getter for property tagSize.
	 * 
	 * @return Value of property tagSize.
	 * 
	 */
	public int getTagSize() {
		return tagSize;
	}

	/**
	 * Setter for property tagSize.
	 * 
	 * @param tagSize
	 *            New value of property tagSize.
	 * 
	 */
	public void setTagSize(int tagSize) {
		this.tagSize = tagSize;
	}

	/**
	 * Getter for property recordSize.
	 * 
	 * @return Value of property recordSize.
	 * 
	 */
	public int getRecordSize() {
		return recordSize;
	}

	/**
	 * Setter for property recordSize.
	 * 
	 * @param recordSize
	 *            New value of property recordSize.
	 * 
	 */
	public void setRecordSize(int recordSize) {
		this.recordSize = recordSize;
	}

	/**
	 * Getter for property unknown3.
	 * 
	 * @return Value of property unknown3.
	 * 
	 */
	public int getUnknown3() {
		return unknown3;
	}

	/**
	 * Setter for property unknown3.
	 * 
	 * @param unknown3
	 *            New value of property unknown3.
	 * 
	 */
	public void setUnknown3(int unknown3) {
		this.unknown3 = unknown3;
	}

	/**
	 * Getter for property unknown4.
	 * 
	 * @return Value of property unknown4.
	 * 
	 */
	public int getUnknown4() {
		return unknown4;
	}

	/**
	 * Setter for property unknown4.
	 * 
	 * @param unknown4
	 *            New value of property unknown4.
	 * 
	 */
	public void setUnknown4(int unknown4) {
		this.unknown4 = unknown4;
	}

	/**
	 * Getter for property unknown5.
	 * 
	 * @return Value of property unknown5.
	 * 
	 */
	public int getUnknown5() {
		return unknown5;
	}

	/**
	 * Setter for property unknown5.
	 * 
	 * @param unknown5
	 *            New value of property unknown5.
	 * 
	 */
	public void setUnknown5(int unknown5) {
		this.unknown5 = unknown5;
	}

	/**
	 * Setter for property songlistHolder.
	 * 
	 * @param songlistHolder
	 *            New value of property songlistHolder.
	 * 
	 */
	public void setSonglistHolder(PodTunesDBListHolder songlistHolder) {
		this.songlistHolder = songlistHolder;
	}

	/**
	 * Setter for property songlistHeader.
	 * 
	 * @param songlistHeader
	 *            New value of property songlistHeader.
	 * 
	 */
	public void setSonglistHeader(PodTunesDBSonglistHeader songlistHeader) {
		this.songlistHeader = songlistHeader;
	}

	/**
	 * Getter for property playlistHolder.
	 * 
	 * @return Value of property playlistHolder.
	 * 
	 */
	public PodTunesDBListHolder getPlaylistHolder() {
		return playlistHolder;
	}

	/**
	 * Setter for property playlistHolder.
	 * 
	 * @param playlistHolder
	 *            New value of property playlistHolder.
	 * 
	 */
	public void setPlaylistHolder(PodTunesDBListHolder playlistHolder) {
		this.playlistHolder = playlistHolder;
	}

	/**
	 * Getter for property playlistHeader.
	 * 
	 * @return Value of property playlistHeader.
	 * 
	 */
	public PodTunesDBPlaylistHeader getPlaylistHeader() {
		return playlistHeader;
	}

	/**
	 * Setter for property playlistHeader.
	 * 
	 * @param playlistHeader
	 *            New value of property playlistHeader.
	 * 
	 */
	public void setPlaylistHeader(PodTunesDBPlaylistHeader playlistHeader) {
		this.playlistHeader = playlistHeader;
	}

} // itunes db
