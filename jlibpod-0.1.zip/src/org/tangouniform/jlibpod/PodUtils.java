package org.tangouniform.jlibpod;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class PodUtils {

	/* --------------------------------------- some endian conversion stuff ---------------------------------- */
	
	// first of all, JVM, Mac, and others are big endian machines
	// PC and iPod are little endians.
	
	/** Decodes a byte array to long
	 *
	 * @return long representation of value
	 * @param value byte array to decode
	 */
	public static long littleEndianToLong( byte[] value )
	{
		long result = ByteBuffer.wrap(value).order( ByteOrder.LITTLE_ENDIAN).getLong();
		
		return result;
	}

	
	/** Decodes a byte array to int
	 *
	 * @return int representation of value
	 * @param value byte array to decode
	 */
	public static int littleEndianToInt(byte[] value)
	{
		int result = ByteBuffer.wrap(value).order( ByteOrder.LITTLE_ENDIAN ).getInt();
		
		return result;
	}
	
	
	/** Encodes a long to an little endianded byte array.
	 *
	 * @param value value to encode
	 * @return byte array containing the value little endianded
	 */
	public static byte[] longToLittleEndian( long value )
	{
		ByteBuffer bb = ByteBuffer.allocate(8).order( ByteOrder.LITTLE_ENDIAN);
		bb.putLong(value);
		
		return bb.array();
	}
	

	/** Encodes a long to an little endianded byte array.
	 *
	 * @param value value to encode
	 * @return byte array containing the value little endianded
	 */
	public static byte[] intToLittleEndian( int value )
	{
		ByteBuffer bb = ByteBuffer.allocate(4).order( ByteOrder.LITTLE_ENDIAN);
		bb.putInt(value);
		
		return bb.array();
	}

	
	/** Converts a little endianed UTF16 byte array into a java string.
	 *
	 * @param value byte array to decode
	 * @return string representing the decoded value
	 */
	public static String uTF16LittleEndianToString( byte[] value)
	{
		// wrap the byte array
		java.nio.CharBuffer cb = ByteBuffer.wrap(value).order( ByteOrder.LITTLE_ENDIAN ).asCharBuffer();

		// get the string
		return cb.toString();
	}
	
	
	/** Converts a java String to an UTF16 little endianed byte array
	 *
	 * @param value string to convert
	 * @return byte array containing the encoded value
	 */
	public static byte[] stringToUTF16LittleEndian( String value )
	{
		// allocate the byte array
		ByteBuffer bb = ByteBuffer.allocate(value.getBytes().length*2).order( ByteOrder.LITTLE_ENDIAN );
		
		// set the value
		bb.asCharBuffer().put(value);
		bb.compact();

		// get the encoded array
		return bb.array();
	}
	
	
	/** Converts a date as long from iPod to a java date as long
	 *
	 * <PRE>
	 * mac date is seconds since 01/01/1904
	 * java date is milliseconds since 01/01/1970
	 * </PRE>
	 *
	 * @return date in java format
	 * @param macDate date on iPod
	 */
	public static long macDateToDate(int macDate)
	{		
		long javaDate = 0;
		
		// offset between java & iPod (Mac) & seconds to milliseconds
		javaDate = (macDate - 2082844800) * 1000;
		
		return javaDate;
	}
	
	
	/** Converts a java date as long to a mac date as long
	 *
	 * <PRE>
	 * mac date is seconds since 01/01/1904
	 * java date is milliseconds since 01/01/1970
	 * </PRE>
	 *
	 * @return date in mac format
	 * @param javaDate date in java format
	 */
	public static int dateToMacDate(long javaDate)
	{
		int macDate = 0;
		
		// milliseconds -> seconds & offset between java & iPod (Mac)
		macDate = (int)( javaDate / 1000 ) + 2082844800;
				
		return macDate;
	}
}
