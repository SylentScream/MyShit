// Copyright (C) 2002-2003 Axel Wernicke <axel.wernicke@gmx.de>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package org.tangouniform.jlibpod;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;




/** Represents an iTunes Database, which contains clip and playlist information.
 *
 * @author  axelwe
 */
public class PodTunesDBParser
{
	
	/** contains temp database for coding / decoding */
	private static PodTunesDB db = null;
	
	/** iTunes db token */
	private static final String DB_RECORD = "mhbd";
	
	/** list holder token */
	private static final String LIST_HOLDER = "mhsd";
	
	/** song list header token */
	private static String SONG_LIST_HEADER = "mhlt";
	
	/** song item token */
	private static final String SONG_ITEM = "mhit";
	
	/** song item content token */
	private static final String SONG_ITEM_CONTENT = "mhod";
	
	/** playlist header token */
	private static final String PLAYLIST_HEADER = "mhlp";
	
	/** playlist item token */
	private static final String PLAYLIST_ITEM = "mhyp";
	
	/** song item index token */
	private static final String PLAYLIST_INDEX_ITEM = "mhip";
	
	/** recent playlist object */
	private PodTunesDBPlaylistItem recentPlaylist = null;
	
	/** recent song object */
	private PodTunesDBSongItem recentSong = null;
	
	/** recent playlistIndexItem object */
	private PodTunesDBPlaylistIndexItem recentPlaylistIndexItem = null;
	
	private String fileName = null;
	
	
	/** Creates a new instance of a parser
	 */
	public PodTunesDBParser()
	{
	}
	
	
	/** Creates a new instance of ITunesDB
	 *
	 * @param _db database to create a parser for
	 */
	public PodTunesDBParser( PodTunesDB _db )
	{
		db = _db;
	}
	
	
	/** Loads the database from an iPod.
	 *
	 * @return the loaded ITunesDB
	 */
	public PodTunesDB load(String fileName)
	{
		this.fileName = fileName;
		PodTunesDB result = null;
		try
		{
			// open data input stream from file
			FileInputStream fis = new FileInputStream( fileName );
			BufferedInputStream bis = new BufferedInputStream( fis, 65532 );
			
			// parse stream
			decode(bis);
			
			// close file
			bis.close();
		
			// destroy local tmp data base
			result = db;
			db = null;
		}
		catch( Exception fnf)
		{
			fnf.printStackTrace();
		}
				
		// return created database
		return result;
	}
	
	
	/** saves the database to an iPod
	 *
	 * @param database ITunesDB to save
	 */
	boolean save(PodTunesDB database)
	{
		boolean success = false;
		// store database temporarily
		db = database;
		
		try
		{
			// open data output stream from file
			FileOutputStream fos = new FileOutputStream( fileName );
			BufferedOutputStream bos = new BufferedOutputStream( fos, 65532 );
			
			// encode stream
			encode(bos);
			
			// close file
			bos.close();
			
			success = true;
		}
		catch( Exception fnf)
		{
			fnf.printStackTrace();
		}
		
		return success;
	}
	
	
	/** decodes the binary database file
	 *
	 * @param fis stream to decode
	 */
	private void decode( InputStream fis )
	{
		
		try
		{
			// do all frames
			byte tag[] = new byte[4];
			
			// parse all tags
			while( fis.read(tag) != -1 )
			{
				
				// ----------- mhbd --------------
				if( new String(tag).equalsIgnoreCase( DB_RECORD ))
				{
					
					// this is the root record, set temp data base
					db = parseDbRecord(fis);
				}
				
				// ----------- mhsd --------------
				else if( new String(tag).equalsIgnoreCase( LIST_HOLDER ))
				{
					PodTunesDBListHolder listHolder = parseListHolder(fis);
					
					// there are usually two list holder records in a database, add depending on type
					if( listHolder.getListType() == PodTunesDBListHolder.SONGLIST )
					{
						db.setSonglistHolder(listHolder);
					}
					else if( listHolder.getListType() == PodTunesDBListHolder.PLAYLIST )
					{
						db.setPlaylistHolder(listHolder);
					}
					else
					{
					}
				}
				
				// ----------- mhlt --------------
				else if( new String(tag).equalsIgnoreCase( SONG_LIST_HEADER ))
				{
					
					// create & decode
					db.setSonglistHeader( parseSonglistHeader(fis) );
				}
				
				// ----------- mhit --------------
				else if( new String(tag).equalsIgnoreCase( SONG_ITEM ) )
				{
					PodTunesDBSongItem songItem = parseSongItem(fis);
					
					// mhit records always belong to the song list, so add it there and mark as recent
					db.getSonglistHeader().addSongItem(songItem);
					recentSong = songItem;
				}
				
				// ----------- mhod --------------
				else if( new String(tag).equalsIgnoreCase( SONG_ITEM_CONTENT ))
				{
					PodTunesDBContentItem contentItem = parseContentItem(fis);
					
					// mhod records may belong to a song, or to an playlist entry, or to an
					// playlist index item - crazy thing :)
					//
					// first check if we have an playlist index item
					if( recentPlaylistIndexItem != null)
					{
						// tweak content
						byte tweak[] = {0x00, 0x00, 0x00, 0x00};
						contentItem.setContent(tweak);
						// set Content changes the content size - we don't want this ...
						contentItem.setContentSize(0);
						
						recentPlaylistIndexItem.addContenItem( contentItem );
					}
					// now try if we have at least an playlist header
					else if( recentPlaylist != null )
					{
						recentPlaylist.getSongItems().addElement( contentItem );
					}
					// otherwise we have an song list content
					else
					{
						// add to song list
						recentSong.getContent().addElement( contentItem );
					}
				}
				
				// ----------- mhlp --------------
				else if( new String(tag).equalsIgnoreCase( PLAYLIST_HEADER ))
				{
					PodTunesDBPlaylistHeader playlistHeader = parsePlaylistHeader(fis);
					
					// since there is only one playlist header, simply add it to the data base
					db.setPlaylistHeader(playlistHeader);
				}
				
				// ----------- mhyp --------------
				else if( new String(tag).equalsIgnoreCase( PLAYLIST_ITEM ))
				{
					PodTunesDBPlaylistItem playlistItem = parsePlaylistItem(fis);
					
					// add to playlist header and mark as recent playlist
					db.getPlaylistHeader().addPlaylist(playlistItem);
					recentPlaylist = playlistItem;
					
					// reset recent index item
					recentPlaylistIndexItem = null;
				}
				
				// ----------- mhip --------------
				else if( new String(tag).equalsIgnoreCase( PLAYLIST_INDEX_ITEM ))
				{
					PodTunesDBPlaylistIndexItem playlistIndexItem = parsePlaylistIndexItem(fis);
					
					// mhip records always belong to a playlist, so append to the most recently added playlist
					recentPlaylist.getSongItems().addElement( playlistIndexItem );
					
					// make this index item the recent one
					recentPlaylistIndexItem = playlistIndexItem;
				}
			}
		}
		catch( Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	
	/** encodes the binary database file
	 *
	 * @param fos stream to write to
	 */
	private void encode( OutputStream fos)
	{
		// encode database header
		encodeDbRecord(fos);
		
		// encode all songs
		if( db.getSonglistHolder() != null )
		{
			encodeListHolder(fos, db.getSonglistHolder());
		}
		
		if( db.getSonglistHeader() != null )
		{
			encodeSonglistHeader(fos);
		}
		
		// encode all playlists
		if( db.getPlaylistHolder() != null )
		{
			encodeListHolder(fos, db.getPlaylistHolder());
		}
		
		if( db.getPlaylistHeader() != null )
		{
			encodePlaylistHeader(fos);
		}
	}
	
	
	/** Parses a db record
	 *
	 * @param fis stream to parse the record from
	 * @return object for the parsed record 
	 */
	private static PodTunesDB parseDbRecord(InputStream fis)
	{
		PodTunesDB db = new PodTunesDB();
		
		try
		{
			byte dword[] = new byte[4];
			
			fis.read(dword);
			db.setTagSize( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			db.setRecordSize( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			db.setUnknown3( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			db.setUnknown4( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			db.setUnknown5( PodUtils.littleEndianToInt(dword) );
			
			int to = db.getTagSize()/4;
			for( int i = 7; i < to; i++)
			{
				fis.read(dword);
//				tmp = littleEndianToInt(dword);
				PodUtils.littleEndianToInt(dword);
//				if( tmp != 0) {	logger.warning("unknwon: " + i +" = " + tmp); }
			}
			
			// log
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return db;
	} // parse bd record
	
	
	/** Encodes a db record.
	 *
	 * @param fos stream to write the db record to
	 */
	static void encodeDbRecord(OutputStream fos)
	{
		try
		{
			byte tag[] = {'m', 'h', 'b', 'd'};
			fos.write( tag );
			fos.write( PodUtils.intToLittleEndian(db.getTagSize()) );
			fos.write( PodUtils.intToLittleEndian(db.getRecordSize()) );
			fos.write( PodUtils.intToLittleEndian(db.getUnknown3()) );
			fos.write( PodUtils.intToLittleEndian(db.getUnknown4()) );
			fos.write( PodUtils.intToLittleEndian(db.getUnknown5()) );
			
			// write padding
			int to = db.getTagSize() - (6*4);
			for( int i = 0; i < to; i++)
			{
				fos.write(0x00);
			}
			
			// logging
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	} // encode db record
	
	
	/** Parses a list holder token
	 *
	 * @param fis stream to parse from
	 * @return parsed object
	 */
	private static PodTunesDBListHolder parseListHolder(InputStream fis)
	{
		PodTunesDBListHolder listHolder = new PodTunesDBListHolder();
		
		try
		{
			byte dword[] = new byte[4];
			
			fis.read(dword);
			listHolder.setTagSize( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			listHolder.setRecordSize( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			listHolder.setListType( PodUtils.littleEndianToInt(dword) );
			
			int to = listHolder.getTagSize()/4;
			for( int i = 4; i < to; i++)
			{
				fis.read(dword);
//				tmp = littleEndianToInt(dword);
				PodUtils.littleEndianToInt(dword);
//				if( tmp != 0) { logger.warning("unknown: " + i + " = " + tmp); }
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return listHolder;
	}// parseListHolder
	
	
	/**
	 * @param fos
	 * @param lh 
	 */
	static void encodeListHolder(OutputStream fos, PodTunesDBListHolder lh)
	{
		try
		{
			byte tag[] = {'m', 'h', 's', 'd'};
			fos.write( tag );
			fos.write( PodUtils.intToLittleEndian(lh.getTagSize()) );
			fos.write( PodUtils.intToLittleEndian(lh.getRecordSize()) );
			fos.write( PodUtils.intToLittleEndian(lh.getListType()) );
			
			// write padding
			int to = lh.getTagSize() - (4*4);
			for( int i = 0; i < to; i++)
			{
				fos.write(0x00);
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	} // encode listHolder
	
	
	/** Parses a songlist header record.
	 * @param fis stream to parse the record from
	 * @return object for the parsed record
	 */
	private static PodTunesDBSonglistHeader parseSonglistHeader(InputStream fis)
	{
		PodTunesDBSonglistHeader songlistHeader = new PodTunesDBSonglistHeader();
		
		try
		{
			byte dword[] = new byte[4];
			
			fis.read(dword);
			songlistHeader.setTagSize( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			// this is done implicitly  by adding song items
			// songlistHeader.setSongCount(littleEndianToInt(dword) );
			
			int to = songlistHeader.getTagSize()/4;
			for( int i = 4; i < to; i++)
			{
				fis.read(dword);
//				tmp = littleEndianToInt(dword);
				PodUtils.littleEndianToInt(dword);
//				if( tmp != 0) { logger.warning("unknwon: " + i + " = " + tmp); }
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return songlistHeader;
		
	} // parse song list header
	
	
	/**
	 * @param fos 
	 */
	static void encodeSonglistHeader(OutputStream fos)
	{
		try
		{
			byte tag[] = {'m', 'h', 'l', 't'};
			fos.write( tag );
			fos.write( PodUtils.intToLittleEndian(db.getSonglistHeader().getTagSize()) );
			fos.write( PodUtils.intToLittleEndian(db.getSonglistHeader().getSongCount()) );
			
			// write padding
			int to = db.getSonglistHeader().getTagSize() - (3*4);
			for( int i = 0; i < to; i++)
			{
				fos.write(0x00);
			}
			
			// encode all song list items
			int songCount = db.getSonglistHeader().getSongCount();
			for(int i = 0; i < songCount; i++)
			{
				encodeSongItem( fos, db.getSonglistHeader().getSongItem(i) );
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	} // encode songlist header
	
	
	/** Parses a song item record.
	 *
	 * @param fis stream to parse the record from
	 * @return object for the parsed record
	 */
	private static PodTunesDBSongItem parseSongItem(InputStream fis)
	{
		PodTunesDBSongItem songItem = new PodTunesDBSongItem();
		
		try
		{
			byte dword[] = new byte[4];
			
			fis.read(dword); songItem.setTagSize(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setRecordSize(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setContentCount(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setRecordIndex(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setUnknown6(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setUnknown7(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setUnknown8(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setDate(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setFilesize(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setDuration(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setTrackNumber(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setUnknown13(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setUnknown14(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setBitrate(PodUtils.littleEndianToInt(dword));
			fis.read(dword); songItem.setSamplerate(PodUtils.littleEndianToInt(dword));
			
			// log unknown tags
			int to = songItem.getTagSize()/4;
			for( int i = 17; i < to; i++)
			{
				fis.read(dword);
				//tmp = littleEndianToInt(dword);
				PodUtils.littleEndianToInt(dword);
//				if( tmp != 0) { logger.warning("unknwon: " + i + " = " + tmp); }
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return songItem;
		
	}// parse song item
	
	
	/**
	 * @param fos
	 * @param si 
	 */
	static void encodeSongItem(OutputStream fos, PodTunesDBSongItem si)
	{
		try
		{
			byte tag[] = {'m', 'h', 'i', 't'};
			fos.write( tag );
			fos.write( PodUtils.intToLittleEndian(si.getTagSize()) );
			fos.write( PodUtils.intToLittleEndian(si.getRecordSize()) );
			fos.write( PodUtils.intToLittleEndian(si.getContentCount()) );
			fos.write( PodUtils.intToLittleEndian(si.getRecordIndex()) );
			fos.write( PodUtils.intToLittleEndian(si.getUnknown6()) );
			fos.write( PodUtils.intToLittleEndian(si.getUnknown7()) );
			fos.write( PodUtils.intToLittleEndian(si.getUnknown8()) );
			fos.write( PodUtils.intToLittleEndian(si.getDate()) );
			fos.write( PodUtils.intToLittleEndian(si.getFilesize()) );
			fos.write( PodUtils.intToLittleEndian(si.getDuration()) );
			fos.write( PodUtils.intToLittleEndian(si.getTrackNumber()) );
			fos.write( PodUtils.intToLittleEndian(si.getUnknown13()) );
			fos.write( PodUtils.intToLittleEndian(si.getUnknown14()) );
			fos.write( PodUtils.intToLittleEndian(si.getBitrate()) );
			fos.write( PodUtils.intToLittleEndian(si.getSamplerate()) );
			
			// write padding
			int to = si.getTagSize() - (16*4);
			for( int i = 0; i < to; i++)
			{
				fos.write(0x00);
			}
			
			// encode all content items
			to = si.getContent().size();
			for(int i = 0; i < to; i++)
			{
				encodeContentItem( fos, (PodTunesDBContentItem)si.getContent().get(i) );
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	} // encode song item
	
	
	/** Parses a content item record.
	 *
	 * @param fis stream to parse the record from
	 * @return object for the parsed record
	 */
	private static PodTunesDBContentItem parseContentItem(InputStream fis)
	{
		PodTunesDBContentItem contentItem = new PodTunesDBContentItem();
		
		try
		{
			byte dword[] = new byte[4];
			
			fis.read(dword);
			//songItemContent.tagSize = littleEndianToInt(dword);
			long ts = PodUtils.littleEndianToInt(dword);
			if( ts != contentItem.getTagSize() )
			{
//				logger.warning("parsed tag size does not equal default" + ts + " vs. " + contentItem.getTagSize() );
			}
			
			fis.read(dword);
			// record size is set when setting content
			//long rs = littleEndianToInt(dword);
			
			fis.read(dword);
			contentItem.setContentTyp( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			contentItem.setUnknown5( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			contentItem.setUnknown6( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			contentItem.setListPosition( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			// content size is set when setting content
			long cs = PodUtils.littleEndianToInt(dword);
			
			fis.read(dword);
			contentItem.setUnknown9( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			contentItem.setUnknown10( PodUtils.littleEndianToInt(dword) );
			
			// read til end of tag as content
			byte tmp[] = new byte[(int)cs];
			fis.read(tmp);
			
			// make default endian encoded and set content
			contentItem.setContent( tmp );
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return contentItem;
		
	} // parse song item content
	
	
	/**
	 * @param fos
	 * @param sic 
	 */
	static void encodeContentItem( OutputStream fos, PodTunesDBContentItem sic )
	{
		try
		{
			byte tag[] = {'m', 'h', 'o', 'd'};
			fos.write( tag );
			fos.write( PodUtils.intToLittleEndian( sic.getTagSize() ));
			fos.write( PodUtils.intToLittleEndian( sic.getRecordSize() ));
			fos.write( PodUtils.intToLittleEndian( sic.getContentTyp() ));
			fos.write( PodUtils.intToLittleEndian( sic.getUnknown5() ));
			fos.write( PodUtils.intToLittleEndian( sic.getUnknown6() ));
			fos.write( PodUtils.intToLittleEndian( sic.getListPosition() ));
			fos.write( PodUtils.intToLittleEndian( sic.getContentSize() ));
			fos.write( PodUtils.intToLittleEndian( sic.getUnknown9() ));
			fos.write( PodUtils.intToLittleEndian( sic.getUnknown10() ));
			
			fos.write( sic.getContent() );
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	} // encode song item content
	
	
	/** Parses a playlist index item record.
	 *
	 * @param fis stream to parse from
	 * @return object for the parsed record
	 */
	private static PodTunesDBPlaylistIndexItem parsePlaylistIndexItem(InputStream fis)
	{
		PodTunesDBPlaylistIndexItem playlistIndexItem = new PodTunesDBPlaylistIndexItem();
		
		try
		{
			byte dword[] = new byte[4];
			
			fis.read(dword);
			playlistIndexItem.setTagSize(PodUtils.littleEndianToInt(dword));
			
			fis.read(dword);
			playlistIndexItem.setRecordSize(PodUtils.littleEndianToInt(dword));
			
			fis.read(dword);
			// set implicitly by adding content items
			// playlistIndexItem.setContentCount(littleEndianToInt(dword));
			
			fis.read(dword);
			playlistIndexItem.setUnknown5(PodUtils.littleEndianToInt(dword));
			
			fis.read(dword);
			playlistIndexItem.setUnknown6(PodUtils.littleEndianToInt(dword));
			
			fis.read(dword);
			playlistIndexItem.setSongIndex(PodUtils.littleEndianToInt(dword));
			
			int to = playlistIndexItem.getTagSize()/4;
			for( int i = 8; i < to; i++)
			{
				fis.read(dword);
//				tmp = littleEndianToInt(dword);
				PodUtils.littleEndianToInt(dword);
//				if( tmp != 0) { logger.warning("unknwon: " + i + " = " + tmp); }
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return playlistIndexItem;
		
	} // parse playlistIndexItem
	
	
	/** Encodes mhip item
	 *
	 * @param fos stream to write to
	 * @param pii playlist index item
	 */
	private static void encodePlaylistIndexItem( OutputStream fos, PodTunesDBPlaylistIndexItem pii )
	{
		try
		{
			byte tag[] = {'m', 'h', 'i', 'p'};
			fos.write( tag );
			fos.write( PodUtils.intToLittleEndian(pii.getTagSize()) );
			fos.write( PodUtils.intToLittleEndian(pii.getRecordSize()) );
			fos.write( PodUtils.intToLittleEndian(pii.getContentCount()) );
			fos.write( PodUtils.intToLittleEndian(pii.getUnknown5()) );
			fos.write( PodUtils.intToLittleEndian(pii.getUnknown6()) );
			fos.write( PodUtils.intToLittleEndian(pii.getSongIndex()) );
			
			// write padding
			int to = pii.getTagSize() - (7*4);
			for( int i = 0; i < to; i++)
			{
				fos.write(0x00);
			}
			
			// write attached content items
			for( int i = 0; i < pii.getContentCount(); i++ )
			{
				encodeContentItem(fos, (PodTunesDBContentItem)pii.getContentItem(i) );
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	} // encode song item index
	
	
	/** Parses a playlist header record.
	 *
	 * @param fis stream to parse the record from
	 * @return object for the parsed record
	 */
	private static PodTunesDBPlaylistHeader parsePlaylistHeader(InputStream fis)
	{
		PodTunesDBPlaylistHeader playlistHeader = new PodTunesDBPlaylistHeader();
		
		try
		{
			byte dword[] = new byte[4];
			
			fis.read(dword);
			playlistHeader.setTagSize( PodUtils.littleEndianToInt(dword) );
			
			fis.read(dword);
			// done implicitly playlistHeader.playlistCount = littleEndianToInt(dword);
			
			int to = playlistHeader.getTagSize()/4;
			for( int i = 4; i < to; i++)
			{
				fis.read(dword);
//				tmp = littleEndianToInt(dword);
				PodUtils.littleEndianToInt(dword);
//				if( tmp != 0) { logger.warning("unknwon: " + i + " = " + tmp); }
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return playlistHeader;
		
	} // parse playlist header
	
	
	/** Encodes a playlist header item of an iTunes DB
	 *
	 * @param fos Stream to encode into
	 */
	void encodePlaylistHeader(OutputStream fos)
	{
		try
		{
			byte tag[] =
			{'m', 'h', 'l', 'p'};
			fos.write( tag );
			fos.write( PodUtils.intToLittleEndian(db.getPlaylistHeader().getTagSize()) );
			fos.write( PodUtils.intToLittleEndian(db.getPlaylistHeader().getPlaylistCount()) );
			
			// write padding
			for( int i = 0; i < db.getPlaylistHeader().getTagSize() - (3*4); i++)
			{
				fos.write(0x00);
			}
			
			// encode all attached playlists
			int playlistCount = db.getPlaylistHeader().getPlaylistCount();
			for(int i = 0; i < playlistCount; i++)
			{
				encodePlaylistItem(fos, db.getPlaylistHeader().getPlaylist(i) );
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	} // encode playlist header
	
	
	/** Parses a playlist item record.
	 *
	 * @param fis stream to parse the record from
	 * @return object for the parsed record
	 */
	private static PodTunesDBPlaylistItem parsePlaylistItem(InputStream fis)
	{
		PodTunesDBPlaylistItem playlistItem = new PodTunesDBPlaylistItem();
		
		try
		{
			byte dword[] = new byte[4];
			
			fis.read(dword);
			playlistItem.setTagSize(PodUtils.littleEndianToInt(dword));
			
			fis.read(dword);
			playlistItem.setRecordSize(PodUtils.littleEndianToInt(dword));
			
			fis.read(dword);
			playlistItem.setContentCount(PodUtils.littleEndianToInt(dword));
			
			fis.read(dword);
			playlistItem.setSongCount(PodUtils.littleEndianToInt(dword));
			
			fis.read(dword);
			playlistItem.setListType(PodUtils.littleEndianToInt(dword));
			
			int to = playlistItem.getTagSize()/4;
			for( int i = 7; i < to; i++)
			{
				fis.read(dword);
//				tmp = littleEndianToInt(dword);
				PodUtils.littleEndianToInt(dword);
//				if( tmp != 0) { logger.warning("unknwon: " + i + " = " + tmp); }		
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return playlistItem;
		
	} // parse playlist item
	
	
	/**
	 * @param fos
	 * @param pi
	 */
	void encodePlaylistItem( OutputStream fos, PodTunesDBPlaylistItem pi )
	{
		try
		{
			byte tag[] = {'m', 'h', 'y', 'p'};
			fos.write( tag );
			fos.write( PodUtils.intToLittleEndian(pi.getTagSize()) );
			fos.write( PodUtils.intToLittleEndian(pi.getRecordSize()) );
			fos.write( PodUtils.intToLittleEndian(pi.getContentCount()) );
			fos.write( PodUtils.intToLittleEndian(pi.getSongCount()) );
			fos.write( PodUtils.intToLittleEndian(pi.getListType()) );
			
			// write padding
			int to = pi.getTagSize() - (6*4);
			for( int i = 0; i < to; i++)
			{
				fos.write(0x00);
			}
			
			// encode all attached playlist entries
			int songCnt = pi.getSongItems().size();
			for(int i = 0; i < songCnt; i++)
			{
				Object tmp = pi.getSongItems().get(i);				
				if( tmp instanceof PodTunesDBPlaylistIndexItem )
				{
					// encode all index entries
					encodePlaylistIndexItem( fos, (PodTunesDBPlaylistIndexItem)tmp );
				}
				else
				{
					// encode content item
					PodTunesDBParser.encodeContentItem( fos, (PodTunesDBContentItem)tmp );
				}
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	} // encode playlist item
	
	
	/** Calculates the _real_ size of the object.
	 * 	The object is encoded into a byte array to determine size.
	 *
	 * @return real size of the record
	 * @param obj
	 */
	int calculateRecordSize(Object obj)
	{
		int size = 0;
		
		try
		{
			ByteArrayOutputStream bau = new ByteArrayOutputStream();

			// axelwe 030705 if( obj.getClass().getName().equals("de.axelwernicke.mypod.ipod.ITunesDB") )
			if( obj instanceof PodTunesDB )
			{
				PodTunesDBParser.encodeDbRecord(bau);
				PodTunesDBParser.encodeListHolder(bau, db.getSonglistHolder());
				PodTunesDBParser.encodeSonglistHeader(bau);
				PodTunesDBParser.encodeListHolder(bau, db.getPlaylistHolder());
				encodePlaylistHeader(bau);
			}
			// axelwe 030705 else if( obj.getClass().getName().equals("de.axelwernicke.mypod.ipod.ITunesDBContentItem") )
			else if( obj instanceof PodTunesDBContentItem )
			{
				PodTunesDBParser.encodeContentItem(bau, (PodTunesDBContentItem)obj);			
			}
			// axelwe 030705 else if( obj.getClass().getName().equals("de.axelwernicke.mypod.ipod.ITunesDBListHolder") )
			else if( obj instanceof PodTunesDBListHolder )
			{
				PodTunesDBParser.encodeListHolder(bau, (PodTunesDBListHolder)obj);
				if( ((PodTunesDBListHolder)obj).getListType() == PodTunesDBListHolder.SONGLIST)
				{
					PodTunesDBParser.encodeListHolder(bau, db.getSonglistHolder());
					PodTunesDBParser.encodeSonglistHeader(bau);				
				}
				else
				{
					PodTunesDBParser.encodeListHolder(bau, db.getPlaylistHolder());
					encodePlaylistHeader(bau);				
				}
			}
			else if( obj instanceof PodTunesDBPlaylistHeader )
			{
				encodePlaylistHeader(bau);			
			}
			else if( obj instanceof PodTunesDBPlaylistIndexItem )
			{
				PodTunesDBParser.encodePlaylistIndexItem(bau, (PodTunesDBPlaylistIndexItem)obj);			
			}
			else if( obj instanceof PodTunesDBPlaylistItem )
			{
				this.encodePlaylistItem(bau, (PodTunesDBPlaylistItem)obj);			
			}
			else if( obj instanceof PodTunesDBSongItem )
			{
				PodTunesDBParser.encodeSongItem(bau, (PodTunesDBSongItem)obj);			
			}
			else if( obj instanceof PodTunesDBSonglistHeader )
			{
				PodTunesDBParser.encodeSonglistHeader(bau);			
			}

			bau.flush();
			size = bau.size();
			bau.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return size;
	}
	

} // ITunes db Parser
