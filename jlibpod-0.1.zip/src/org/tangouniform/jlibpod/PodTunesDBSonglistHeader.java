// ITunesDBSonglistHeader
// $Id: ITunesDBSonglistHeader.java,v 1.13 2003/07/26 07:06:54 axelwernicke Exp $
//
// Copyright (C) 2002-2003 Axel Wernicke <axel.wernicke@gmx.de>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package org.tangouniform.jlibpod;

import java.util.Vector;
import java.util.Iterator;


/** A SongListHeader object stores the informations from the mhlt tag. It has
 *	references to the songs in the list.
 *
 * <PRE>
 *	mhlt:
 *	x00	'mhlt'				- tag
 *	x04								- tag size
 *	x08								- total count of songs in the list
 * </PRE>
 * @see techdoc for more details
 * @author axelwe
 */
public class PodTunesDBSonglistHeader
{
	/** tag size inn bytes */
	private int tagSize = 92;
	/** list of song items - all items stored on the iPod are in here !! */
	private Vector songItems;

	
	/** Standard Construcor for a Song list item. */	
	PodTunesDBSonglistHeader()
	{
		songItems = new Vector();
	};
	
	
	/** Adds a Clip to iTunes DB Songlist.
	 *	a new song item containing all meta data is created and added to the songlist
	 *
	 * @param fileIndex of to clip in the iTunes DB
	 * @param meta data of the clip
	 * @return size of the created song item
	 */	
	int addClip(int fileIndex, MP3Meta meta)
	{
		// create song item
		PodTunesDBSongItem songItem = new PodTunesDBSongItem();
		
		// set meta data
		songItem.setDate( PodUtils.dateToMacDate( System.currentTimeMillis() ) );
		songItem.setDuration( (int)meta.getDuration()*1000 ); // duration is ms in iTunes DB
		songItem.setFilesize( (int)meta.getFilesize() );
		songItem.setRecordIndex(fileIndex);
		songItem.setTrackNumber(meta.getTrack());
		songItem.setUnknown8(256); // TODO: - not sure what that meta data means in the db
//		songItem.unknown6 = 0;
//		songItem.unknown7 = 0;
//		songItem.unknown13 = 0;
//		songItem.unknown14 = 0;
		songItem.setBitrate(meta.getBitrate());
//		songItem.unknown16 = 0;
		
		// create song content items		
		songItem.attachContent( new PodTunesDBContentItem(	PodTunesDBContentItem.FILETYPE, 1,
				PodUtils.stringToUTF16LittleEndian("MPEG audio file") ) );

		/** TODO: take care of this when switching to store files in other directories than F00 */
		String path = new StringBuffer(":iPod_Control:Music:F00:").append(fileIndex).append( ".mp3").toString();
		songItem.attachContent( new PodTunesDBContentItem(	PodTunesDBContentItem.PATH, 1,
				PodUtils.stringToUTF16LittleEndian(path) ) );
	
		String artist = meta.getArtist();
		if( artist != null && artist.length() != 0)
		{
			songItem.attachContent( new PodTunesDBContentItem(	PodTunesDBContentItem.ARTIST, 1,
					PodUtils.stringToUTF16LittleEndian(artist) ) );
		}

		String album = meta.getAlbum();
		if( album != null && album.length() != 0)
		{
			songItem.attachContent( new PodTunesDBContentItem(	PodTunesDBContentItem.ALBUM, 1, 
					PodUtils.stringToUTF16LittleEndian(album) ) );
		}

		String comment = meta.getComment();
		if( comment != null && comment.length() != 0)
		{
			songItem.attachContent( new PodTunesDBContentItem( PodTunesDBContentItem.COMMENT, 1,
					PodUtils.stringToUTF16LittleEndian(comment) ) );
		}

		String genre = meta.getGenre();
		if( genre != null && genre.length() != 0)
		{
			songItem.attachContent( new PodTunesDBContentItem( PodTunesDBContentItem.GENRE, 1,
					PodUtils.stringToUTF16LittleEndian(genre) ) );
		}

		if( meta.getTitle() != null && meta.getTitle().length() != 0)
		{
			songItem.attachContent( new PodTunesDBContentItem( PodTunesDBContentItem.TITEL, 1,
					PodUtils.stringToUTF16LittleEndian(meta.getTitle()) ) );
		}
		
		// add song item to the songlist header and correct song count
		songItems.addElement(songItem);
		
		return songItem.getRecordSize();
	}
	
	
	/** Gets the members of the object as formatted string.
	 * @return formatted string
	 */	
	public String toString()
	{
		return new StringBuffer("[tagSize] ").append(tagSize)
								.append('\t').append("[songCount] ").append(songItems.size())
								.toString();
	}
	
	
	/** Getter for property tagSize.
	 * @return Value of property tagSize.
	 */
	public int getTagSize()
	{
		return tagSize;
	}
	

	/** Setter for property tagSize.
	 * @param tagSize New value of property tagSize.
	 */
	public void setTagSize(int tagSize)
	{
		this.tagSize = tagSize;
	}
	
	
	/** Getter for property songCount.
	 * @return Value of property songCount.
	 *
	 */
	public int getSongCount()
	{
		return songItems.size();
	}
	
	public void addSongItem( PodTunesDBSongItem songItem )
	{
		this.songItems.add(songItem);
	}
	
	public PodTunesDBSongItem getSongItem( int index )
	{
		return (PodTunesDBSongItem)this.songItems.get(index);
	}
	
	public void removeSongItem( int index )
	{
		this.songItems.removeElementAt(index);
	}
	
	public void removeSongItem( PodTunesDBSongItem songItem )
	{
		this.songItems.remove(songItem);
	}
	
	boolean containsClip(int fileIndex)
	{
		boolean found = false;
		
		// iterate over all songs until we find the searched one...
		PodTunesDBSongItem songItem;
		for( Iterator songIter = this.songItems.iterator(); !found && songIter.hasNext(); )
		{
			songItem = (PodTunesDBSongItem)songIter.next();
			if( songItem.getRecordIndex() == fileIndex )
			{
				found = true;
			}
		}
		
		return found;
	}
	
} // classe song list header